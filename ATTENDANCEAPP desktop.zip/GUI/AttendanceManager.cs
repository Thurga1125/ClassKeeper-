﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SQLite;

namespace GUI
{
    public class AttendanceManager
    {
        private DatabaseHelper dbHelper = new DatabaseHelper();

        public AttendanceManager()
        {
            dbHelper.InitializeDatabase();
        }

        // Add attendance record
        public void AddAttendance(string username, string semester, string module, string status)
        {
            string query = "INSERT INTO Attendance (Username, Semester, Module, Status, Timestamp) VALUES (@Username, @Semester, @Module, @Status, @Timestamp)";
            dbHelper.ExecuteNonQuery(query,
                new SQLiteParameter("@Username", username),
                new SQLiteParameter("@Semester", semester),
                new SQLiteParameter("@Module", module),
                new SQLiteParameter("@Status", status),
                new SQLiteParameter("@Timestamp", DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"))
            );
        }

        // Update attendance record
        public void UpdateAttendance(string username, string semester, string module, string status)
        {
            string query = "UPDATE Attendance SET Status = @Status, Timestamp = @Timestamp WHERE Username = @Username AND Semester = @Semester AND Module = @Module";
            dbHelper.ExecuteNonQuery(query,
                new SQLiteParameter("@Username", username),
                new SQLiteParameter("@Semester", semester),
                new SQLiteParameter("@Module", module),
                new SQLiteParameter("@Status", status),
                new SQLiteParameter("@Timestamp", DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"))
            );
        }

        // Delete attendance record
        public void DeleteAttendance(string username, string semester, string module)
        {
            string query = "DELETE FROM Attendance WHERE Username = @Username AND Semester = @Semester AND Module = @Module";
            dbHelper.ExecuteNonQuery(query,
                new SQLiteParameter("@Username", username),
                new SQLiteParameter("@Semester", semester),
                new SQLiteParameter("@Module", module)
            );
        }

        // Fetch all attendance records
        public List<AttendanceRecord> GetAllAttendance()
        {
            List<AttendanceRecord> records = new List<AttendanceRecord>();
            string query = "SELECT * FROM Attendance";
            using (var reader = dbHelper.ExecuteQuery(query))
            {
                while (reader.Read())
                {
                    records.Add(new AttendanceRecord
                    {
                        Username = reader.GetString(0),
                        Semester = reader.GetString(1),
                        Module = reader.GetString(2),
                        Status = reader.GetString(3),
                        Timestamp = reader.GetString(4)
                    });
                }
            }
            return records;
        }
    }
}
