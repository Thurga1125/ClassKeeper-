﻿using System;
using System.Windows;
using System.Windows.Controls;

namespace GUI
{
    public partial class Spring2023 : Window
    {
        public Spring2023()
        {
            InitializeComponent();
        }

        // Event handler for CS670 button click
        private void CS670_Click(object sender, RoutedEventArgs e)
        {
            // Create an instance of the StudentForm window
            StudentForm studentForm = new StudentForm();
            studentForm.WindowState = WindowState.Normal; // Ensure StudentForm opens in normal state

            // Show the StudentForm window
            studentForm.Show();

            // Optionally, hide the current window (Spring2023)
            this.Hide();
        }

        // Event handler for CO432 button click
        private void CO432_Click(object sender, RoutedEventArgs e)
        {
            // Create an instance of the StudentForm window
            StudentForm studentForm = new StudentForm();
            studentForm.WindowState = WindowState.Normal; // Ensure StudentForm opens in normal state

            // Show the StudentForm window
            studentForm.Show();

            // Optionally, hide the current window (Spring2023)
            this.Hide();
        }
    }
}
