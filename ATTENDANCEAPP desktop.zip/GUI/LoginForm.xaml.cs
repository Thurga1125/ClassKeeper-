﻿using System;
using System.Windows;

namespace GUI
{
    public partial class LoginForm : Window
    {
        public LoginForm()
        {
            InitializeComponent();
        }

        private void LoginButton_Click(object sender, RoutedEventArgs e)
        {
            string username = UsernameTextBox.Text;
            string password = PasswordBox.Password;

            // Check if username or password is empty
            if (string.IsNullOrEmpty(username) || string.IsNullOrEmpty(password))
            {
                MessageBox.Show("Please enter both username and password.", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
            else
            {
                // Validate the credentials (you can replace this with actual logic)
                if (username == "rcb" && password == "123") // Example check
                {
                    // Navigate to the MainForm
                    MainForm mainForm = new MainForm();
                    mainForm.WindowState = WindowState.Normal; // Ensure MainForm opens in normal state
                    mainForm.Show();
                    this.Close(); // Close the LoginForm
                }
                else
                {
                    MessageBox.Show("Invalid username or password", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
                }
            }
        }

        // When the Username TextBox gets focus, hide the watermark
        private void UsernameTextBox_GotFocus(object sender, RoutedEventArgs e)
        {
            UsernameWatermark.Visibility = Visibility.Collapsed;
        }

        // When the Username TextBox loses focus, show the watermark if the textbox is empty
        private void UsernameTextBox_LostFocus(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrEmpty(UsernameTextBox.Text))
            {
                UsernameWatermark.Visibility = Visibility.Visible;
            }
        }

        // When the Password Box gets focus, hide the watermark
        private void PasswordBox_GotFocus(object sender, RoutedEventArgs e)
        {
            PasswordWatermark.Visibility = Visibility.Collapsed;
        }

        // When the Password Box loses focus, show the watermark if the password box is empty
        private void PasswordBox_LostFocus(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrEmpty(PasswordBox.Password))
            {
                PasswordWatermark.Visibility = Visibility.Visible;
            }
        }
    }
}
