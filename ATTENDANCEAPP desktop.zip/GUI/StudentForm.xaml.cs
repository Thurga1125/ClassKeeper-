﻿using System;
using System.Windows;

namespace GUI
{
    public partial class StudentForm : Window
    {
        private string studentID = "TestUser"; // Hardcoded logged-in user
        private DateTime? attendanceDate = null; // Store attendance timestamp

        public StudentForm()
        {
            InitializeComponent();
        }

        // Event handler for the checkbox click to mark attendance
        private void markAttendanceCheckBox_Checked(object sender, RoutedEventArgs e)
        {
            if (attendanceDate == null)
            {
                // Mark new attendance
                attendanceDate = DateTime.Now;
                MessageBox.Show($"{studentID}, your attendance was counted successfully!\nDate: {attendanceDate}");
            }
            else
            {
                // Update attendance
                attendanceDate = DateTime.Now;
                MessageBox.Show($"{studentID}, your attendance has been updated!\nNew Date: {attendanceDate}");
            }
        }

        // Event handler for the checkbox click to unmark attendance (delete)
        private void markAttendanceCheckBox_Unchecked(object sender, RoutedEventArgs e)
        {
            if (attendanceDate != null)
            {
                MessageBoxResult result = MessageBox.Show("Do you want to delete your attendance?", "Delete Attendance", MessageBoxButton.YesNo, MessageBoxImage.Warning);
                if (result == MessageBoxResult.Yes)
                {
                    attendanceDate = null;
                    MessageBox.Show("Your attendance has been deleted.");
                }
                else
                {
                    // If user cancels, recheck the checkbox
                    markAttendanceCheckBox.IsChecked = true;
                }
            }
        }

        // Event handler for the update button click - Navigates to MainForm
        private void Update_Click(object sender, RoutedEventArgs e)
        {
            MainForm mainForm = new MainForm();
            mainForm.WindowState = WindowState.Normal; // Ensure MainForm opens in normal state
            mainForm.Show();
            this.Close(); // Close the StudentForm
        }

        // Event handler for the logout button click
        private void Logout_Click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("You have logged out!");
            this.Close(); // Close the StudentForm
        }
    }
}
