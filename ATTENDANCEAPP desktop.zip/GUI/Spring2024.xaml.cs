﻿using System;
using System.Windows;
using System.Windows.Controls;

namespace GUI
{
    public partial class Spring2024 : Window
    {
        public Spring2024()
        {
            InitializeComponent();
        }

        // Event handler for CO321 button click
        private void CO321_Click(object sender, RoutedEventArgs e)
        {
            // Create an instance of the StudentForm window
            StudentForm studentForm = new StudentForm();
            studentForm.WindowState = WindowState.Normal; // Ensure StudentForm opens in normal state

            // Show the StudentForm window
            studentForm.Show();

            // Optionally, hide the current window (Spring2024)
            this.Hide();
        }

        // Event handler for CS112 button click
        private void CS112_Click(object sender, RoutedEventArgs e)
        {
            // Create an instance of the StudentForm window
            StudentForm studentForm = new StudentForm();
            studentForm.WindowState = WindowState.Normal; // Ensure StudentForm opens in normal state

            // Show the StudentForm window
            studentForm.Show();

            // Optionally, hide the current window (Spring2024)
            this.Hide();
        }
    }
}
