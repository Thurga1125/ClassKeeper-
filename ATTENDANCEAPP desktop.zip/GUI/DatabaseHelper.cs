﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SQLite;

namespace GUI
{
   
        public class DatabaseHelper
        {
            private string connectionString = "Data Source=attendance.db;Version=3;";

            // Initialize Database and Create Table if it doesn't exist
            public void InitializeDatabase()
            {
                using (var connection = new SQLiteConnection(connectionString))
                {
                    connection.Open();
                    string createTableQuery = @"CREATE TABLE IF NOT EXISTS Attendance (
                                            Username TEXT NOT NULL,
                                            Semester TEXT NOT NULL,
                                            Module TEXT NOT NULL,
                                            Status TEXT NOT NULL,
                                            Timestamp TEXT NOT NULL)";
                    using (var command = new SQLiteCommand(createTableQuery, connection))
                    {
                        command.ExecuteNonQuery();
                    }
                }
            }

            // Execute non-query commands (INSERT, UPDATE, DELETE)
            public void ExecuteNonQuery(string query, params SQLiteParameter[] parameters)
            {
                using (var connection = new SQLiteConnection(connectionString))
                {
                    connection.Open();
                    using (var command = new SQLiteCommand(query, connection))
                    {
                        command.Parameters.AddRange(parameters);
                        command.ExecuteNonQuery();
                    }
                }
            }

            // Execute query and return reader (for SELECT)
            public SQLiteDataReader ExecuteQuery(string query, params SQLiteParameter[] parameters)
            {
                var connection = new SQLiteConnection(connectionString);
                connection.Open();
                using (var command = new SQLiteCommand(query, connection))
                {
                    command.Parameters.AddRange(parameters);
                    return command.ExecuteReader();
                }
            }
        }
    
}
