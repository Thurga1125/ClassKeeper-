﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SQLite;

namespace GUI
{
    public class AttendanceRecord
    {
        public string Username { get; set; }
        public string Semester { get; set; }
        public string Module { get; set; }
        public string Status { get; set; }
        public string Timestamp { get; set; }
    }
}
