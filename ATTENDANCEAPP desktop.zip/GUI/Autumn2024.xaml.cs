﻿using System;
using System.Windows;

namespace GUI
{
    public partial class Autumn2024 : Window
    {
        public Autumn2024()
        {
            InitializeComponent();
        }

        // Event handler for CO215 button click
        private void CO215_Click(object sender, RoutedEventArgs e)
        {
            OpenStudentForm("CO215"); // Open the student form for CO215 module
        }

        // Event handler for CO432 button click
        private void CO432_Click(object sender, RoutedEventArgs e)
        {
            OpenStudentForm("CO432"); // Open the student form for CO432 module
        }

        // Method to open StudentForm for a given module code
        private void OpenStudentForm(string moduleCode)
        {
            StudentForm studentForm = new StudentForm(); // Instantiate the StudentForm window
            studentForm.WindowState = WindowState.Normal; // Ensure StudentForm opens in normal state
            MessageBox.Show($"Opening StudentForm for {moduleCode}"); // Display the selected module in a message box
            studentForm.Show(); // Show the StudentForm window
            this.Hide(); // Hide the current Autumn2024 window
        }
    }
}
