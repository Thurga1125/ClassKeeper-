﻿using System;
using System.Windows;

namespace GUI
{
    public partial class StudentForm : Window
    {
        public StudentForm()
        {
            InitializeComponent(); // Initialize components from XAML
        }

        // Event handler for the checkbox click to mark attendance
        private void markAttendanceCheckBox_Checked(object sender, RoutedEventArgs e)
        {
            string studentID = "TestUser"; // Hardcoded logged-in user (since no backend)
            DateTime date = DateTime.Now;

            // Displaying attendance marked message
            MessageBox.Show($"Attendance Marked Successfully!\nStudent ID: {studentID}\nDate: {date}");
        }

        // Event handler for the checkbox click to unmark attendance
        private void markAttendanceCheckBox_Unchecked(object sender, RoutedEventArgs e)
        {
            // Displaying attendance unmarked message
            MessageBox.Show("Attendance unmarked!");
        }

        // Event handler for the logout button click
        private void Logout_Click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("You have logged out!");
            this.Close(); // Close the StudentForm
        }
    }
}
