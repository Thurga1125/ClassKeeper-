﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace GUI
{
    public partial class Spring2023 : Window
    {
        public Spring2023()
        {
            InitializeComponent();
        }

        // Event handler for CS670 button click
        private void CS670_Click(object sender, RoutedEventArgs e)
        {
            // Create an instance of the StudentForm window
            StudentForm studentForm = new StudentForm();

            // Show the StudentForm window
            studentForm.Show();

            // Optionally, hide the current window (Spring2023)
            this.Hide();
        }

        // Event handler for CO432 button click
        private void CO432_Click(object sender, RoutedEventArgs e)
        {
            // Create an instance of the StudentForm window
            StudentForm studentForm = new StudentForm();

            // Show the StudentForm window
            studentForm.Show();

            // Optionally, hide the current window (Spring2023)
            this.Hide();
        }
    }
}
