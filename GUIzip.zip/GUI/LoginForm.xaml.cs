﻿using GUI;
using System;
using System.Windows;

namespace desktopapp
{
    public partial class LoginForm : Window
    {
        public LoginForm()
        {
            InitializeComponent();
        }

        private void LoginButton_Click(object sender, RoutedEventArgs e)
        {
            string username = txtUsername.Text;  // Get the username from the textbox
            string password = txtPassword.Password;  // Get the password from the password box

            // Check if username or password is empty
            if (string.IsNullOrWhiteSpace(username) || string.IsNullOrWhiteSpace(password))
            {
                lblErrorMessage.Text = "Username and Password cannot be empty!";
                lblErrorMessage.Visibility = Visibility.Visible;
            }
            else
            {
                // If both username and password are filled, proceed to login
                MessageBox.Show("Login Successful!");

                // Open the MainForm after successful login
                MainForm mainForm = new MainForm();
                mainForm.Show();

                // Close the LoginForm (this will not exit the app)
                this.Close();
            }
        }
    }
}
