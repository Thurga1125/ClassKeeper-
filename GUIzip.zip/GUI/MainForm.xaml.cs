﻿using System;
using System.Windows;

namespace GUI // Ensure namespace matches your project
{
    public partial class MainForm : Window
    {
        public MainForm()
        {
            InitializeComponent(); // Ensure initialization is done
        }

        // Event handler for Spring Semester 2024 button click
        private void Spring2024_Click(object sender, RoutedEventArgs e)
        {
            Spring2024 spring2024Form = new Spring2024();
            spring2024Form.Show(); // Open Spring2024 window
            this.Close(); // Close MainForm
        }

        // Event handler for Autumn Semester 2024 button click
        private void Autumn2024_Click(object sender, RoutedEventArgs e)
        {
            Autumn2024 autumn2024Form = new Autumn2024();
            autumn2024Form.Show(); // Open Autumn2024 window
            this.Close(); // Close MainForm
        }

        // Event handler for Spring Semester 2023 button click
        private void Spring2023_Click(object sender, RoutedEventArgs e)
        {
            Spring2023 spring2023Form = new Spring2023();
            spring2023Form.Show(); // Open Spring2023 window
            this.Close(); // Close MainForm
        }
    }
}
